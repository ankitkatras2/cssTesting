import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-underwater-pattern',
  templateUrl: './underwater-pattern.component.html',
  styleUrls: ['./underwater-pattern.component.css']
})
export class UnderwaterPatternComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
