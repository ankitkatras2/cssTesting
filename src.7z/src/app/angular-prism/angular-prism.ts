//import { NgModule, ModuleWithProviders } from '@angular/core';
//import { CommonModule } from '@angular/common';
import { PrismComponent } from './src/prism.component';

export * from './src/prism.component';
